const array = [
    {
        id: "1",
        Name: "Anubhav",
        Age: "18",
    },
    {
        id: "2",
        Name: "Sneah",
        Age: "22",
    },
    {
        id: "3",
        Name: "Rahul",
        Age: "23",
    },
];
 
export default array;